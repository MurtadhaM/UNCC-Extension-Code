
var css = chrome.runtime.getURL('49EXPRESS.css');
var state_value = chrome.storage.sync.get([ 'state' ]);

console.log(css)

console.log(state_value)

