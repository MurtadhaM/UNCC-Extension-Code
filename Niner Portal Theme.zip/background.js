// let theme = 'Dark';
// let state = 'off';


// chrome.runtime.onInstalled.addListener(() => {
//   chrome.storage.sync.set({ theme });
//   chrome.storage.sync.set({ state });
//   console.log('Default state set to on', `theme: ${theme}`);
// });
 

