# Niner Portal Face Lift

# <h1 align='center'><img src='https://emojis.slackmojis.com/emojis/images/1577982316/7421/typingcat.gif?1577982316' width=30/> Project Spiffy UNCC</h1>



<p align="center" ><img width=100 src="https://i.pinimg.com/564x/b0/48/e3/b048e3fe8ce574e87faba2d9e240645f--team-logo-brand-identity.jpg" alt="UNCC Logo"></p>



## Table of Contents

- [Background](#background)
- [Links](#Links)
- [Screenshots](#Screenshots)
- [License](#license)
- [Team](#Team)


## Background

##### I chose this project because I wanted to leave UNCC with a project I worked on to share with other student to make 49er portal more asthetically pleasing. 




## Links (***Pending***)
| Browser    | Link                                                                                           |
|:----------|:--------------------------------------------------------------------------------------------------|
| **Chrome**  |  <a href="https://chrome.google.com/webstore/category/extensions"> Chrome Web Store </a> |
| **Firefox**  | <a href="https://chrome.google.com/webstore/category/extensions"> Firefox Extension Store </a>   |
| **Netscape** | <a href="https://i.imgflip.com/12kxne.jpg"> It is a Surprise </a> |


## Screenshots
<img  width=180 src="https://raw.githubusercontent.com/MurtadhaM/UNCC-Extension-Code/main/Screenshots/1.png" alt="1st ">

<img  width=180 src="https://raw.githubusercontent.com/MurtadhaM/UNCC-Extension-Code/main/Screenshots/2.png" alt="2nd ">

<img  width=180 src="https://raw.githubusercontent.com/MurtadhaM/UNCC-Extension-Code/main/Screenshots/3.png" alt="3rd ">




## License
##### This project is licensed under the MIT license.


## Team
<img  width=180 src="https://webpages.uncc.edu/mmarzouq/assets/img/background.jpg" alt="Murtadha Marzou ">
[Murtadha Marzouq](https://webpages.uncc.edu/mmarzouq)
